#!/usr/bin/env bash
# Revault - private website saver
set -e
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "=============================================="
echo "  Revault setup"
echo "=============================================="
echo ""

echo "[1/3] Checking for Java 17+..."
JAVACMD=""
if [ -n "${JAVA_HOME:-}" ] && [ -x "${JAVA_HOME}/bin/java" ]; then
  JAVACMD="${JAVA_HOME}/bin/java"
elif command -v java >/dev/null 2>&1; then
  JAVACMD="java"
else
  for d in /usr/lib/jvm/java-17-openjdk-amd64 /usr/lib/jvm/java-17-openjdk /usr/lib/jvm/default-java; do
    [ -x "${d}/bin/java" ] 2>/dev/null && export JAVA_HOME="$d" && JAVACMD="${d}/bin/java" && break
  done
fi
[ -z "$JAVACMD" ] && echo "ERROR: Java 17+ required. Install openjdk-17-jdk." && exit 1
JAVA_MAJOR=$("$JAVACMD" -version 2>&1 | head -1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' || echo "0")
[ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 17 ] 2>/dev/null && echo "ERROR: Java 17+ required." && exit 1
echo "      OK: $("$JAVACMD" -version 2>&1 | head -1)"
echo ""

echo "[2/3] Maven..."
MVN_CMD="mvn"
if ! command -v mvn >/dev/null 2>&1; then
  WRAPPER_JAR="$SCRIPT_DIR/.mvn/wrapper/maven-wrapper.jar"
  mkdir -p "$(dirname "$WRAPPER_JAR")"
  if [ ! -r "$WRAPPER_JAR" ]; then
    echo "      Downloading Maven Wrapper..."
    curl -f -L -o "$WRAPPER_JAR" "https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar" 2>/dev/null || wget -q -O "$WRAPPER_JAR" "https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar" 2>/dev/null || true
    [ ! -r "$WRAPPER_JAR" ] && echo "ERROR: Install Maven or check network." && exit 1
  fi
  chmod +x "$SCRIPT_DIR/mvnw" 2>/dev/null
  MVN_CMD="$SCRIPT_DIR/mvnw"
fi
echo ""

echo "[3/3] Build..."
if [ -d "target/classes" ] && [ -z "${REBUILD:-}" ]; then
  $MVN_CMD compile -q || $MVN_CMD clean compile -q
else
  $MVN_CMD clean compile -q
fi
echo ""
echo "Done. Run: ./run.sh"
echo ""
