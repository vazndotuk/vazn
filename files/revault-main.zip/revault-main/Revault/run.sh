#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ -x "./mvnw" ] && [ -r "./.mvn/wrapper/maven-wrapper.jar" ]; then
  exec ./mvnw javafx:run
fi
exec mvn javafx:run
