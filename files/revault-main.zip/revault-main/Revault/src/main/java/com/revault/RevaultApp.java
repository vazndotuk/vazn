package com.revault;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public final class RevaultApp extends Application {

    private static final String PROMPT = "> ";
    private TextArea output;
    private TextField input;
    private List<Storage.SavedSite> sites;
    private int nextId;

    @Override
    public void start(Stage stage) {
        sites = new ArrayList<>(Storage.load());
        nextId = sites.isEmpty() ? 1 : sites.stream().mapToInt(s -> s.id).max().orElse(0) + 1;

        output = new TextArea();
        output.setEditable(false);
        output.setWrapText(true);
        output.setFont(Font.font("Monospaced", 14));
        output.setStyle("-fx-control-inner-background: #0a0a0a; -fx-text-fill: #00aa00; -fx-font-family: Monospaced;");
        output.setPadding(new Insets(8));

        input = new TextField();
        input.setFont(Font.font("Monospaced", 14));
        input.setStyle("-fx-control-inner-background: #0a0a0a; -fx-text-fill: #00ff00; -fx-prompt-text-fill: #556655; -fx-font-family: Monospaced;");
        input.setPromptText("command");
        input.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) runCommand(input.getText().trim());
        });

        HBox bar = new HBox(4);
        bar.setPadding(new Insets(4, 8, 8, 8));
        bar.setStyle("-fx-background-color: #0a0a0a;");
        javafx.scene.control.Label lbl = new javafx.scene.control.Label(PROMPT);
        lbl.setStyle("-fx-text-fill: #00ff00; -fx-font-family: Monospaced; -fx-font-size: 14px;");
        HBox.setHgrow(input, Priority.ALWAYS);
        bar.getChildren().addAll(lbl, input);

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #0a0a0a;");
        root.setCenter(output);
        root.setBottom(bar);

        Scene scene = new Scene(root, 700, 450);
        stage.setTitle("Revault");
        stage.setScene(scene);
        stage.show();
        input.requestFocus();

        println("REVAULT - private website saver");
        println("Type 'help' for commands.");
        println("");
    }

    private void println(String s) {
        output.appendText(s + "\n");
    }

    private void runCommand(String line) {
        if (line.isEmpty()) return;
        println(PROMPT + line);
        input.clear();

        String[] parts = line.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String rest = parts.length > 1 ? parts[1].trim() : "";

        switch (cmd) {
            case "help":
                println("  save <url> [title]   save a site");
                println("  list                 list all");
                println("  open <id>            open in browser");
                println("  delete <id>          remove");
                println("  edit <id> <url>      change url");
                println("  edit <id> -t \"title\" change title");
                println("  clear                clear screen");
                println("  quit                 exit");
                break;
            case "save":
                if (rest.isEmpty()) {
                    println("  usage: save <url> [title]");
                    return;
                }
                String url = rest;
                String title = "";
                if (rest.contains(" ")) {
                    int first = rest.indexOf(' ');
                    url = rest.substring(0, first);
                    title = rest.substring(first).trim();
                }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
                Storage.SavedSite site = new Storage.SavedSite(nextId++, url, title.isBlank() ? url : title);
                sites.add(site);
                Storage.save(sites);
                println("  saved #" + site.id + " " + site.title);
                break;
            case "list":
                if (sites.isEmpty()) {
                    println("  (none)");
                    return;
                }
                for (Storage.SavedSite s : sites) {
                    String t = (s.title != null && !s.title.equals(s.url)) ? s.title : s.url;
                    if (t.length() > 55) t = t.substring(0, 52) + "...";
                    println("  #" + s.id + "  " + t);
                }
                break;
            case "open":
                int oid = parseId(rest);
                if (oid < 0) { println("  usage: open <id>"); return; }
                Storage.SavedSite openSite = find(oid);
                if (openSite == null) { println("  no such id."); return; }
                if (BrowserLauncher.open(openSite.url)) println("  opened.");
                else println("  failed to open browser.");
                break;
            case "delete":
                int did = parseId(rest);
                if (did < 0) { println("  usage: delete <id>"); return; }
                if (sites.removeIf(s -> s.id == did)) {
                    Storage.save(sites);
                    println("  deleted #" + did);
                } else println("  no such id.");
                break;
            case "edit":
                if (rest.isEmpty()) { println("  usage: edit <id> <url> or edit <id> -t \"title\""); return; }
                int eid = parseId(rest);
                if (eid < 0) { println("  invalid id."); return; }
                Storage.SavedSite es = find(eid);
                if (es == null) { println("  no such id."); return; }
                String tail = rest.replaceFirst("^\\d+\\s*", "").trim();
                if (tail.toLowerCase().startsWith("-t ")) {
                    String newTitle = tail.substring(2).trim().replaceAll("^\"|\"$", "");
                    es.title = newTitle.isEmpty() ? es.url : newTitle;
                } else if (!tail.isEmpty()) {
                    es.url = tail.startsWith("http") ? tail : "https://" + tail;
                }
                Storage.save(sites);
                println("  updated #" + eid);
                break;
            case "clear":
                output.clear();
                break;
            case "quit":
            case "exit":
                Platform.exit();
                break;
            default:
                println("  unknown command. Type 'help'.");
        }
    }

    private int parseId(String s) {
        if (s == null || s.isBlank()) return -1;
        s = s.split("\\s+")[0];
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return -1; }
    }

    private Storage.SavedSite find(int id) {
        for (Storage.SavedSite s : sites) if (s.id == id) return s;
        return null;
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
