package com.revault;

import java.util.Locale;

/** Opens URL in system browser (no AWT). */
public final class BrowserLauncher {
    public static boolean open(String url) {
        if (url == null || url.isBlank()) return false;
        String u = url.trim();
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        try {
            if (os.contains("nux") || os.contains("nix")) {
                new ProcessBuilder("xdg-open", u).start();
                return true;
            }
            if (os.contains("mac") || os.contains("darwin")) {
                new ProcessBuilder("open", u).start();
                return true;
            }
            if (os.contains("win")) {
                new ProcessBuilder("cmd", "/c", "start", "", u).start();
                return true;
            }
            new ProcessBuilder("xdg-open", u).start();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
