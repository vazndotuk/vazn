package com.revault;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Saves and loads bookmarks to ~/.revault/saved_sites.json */
public final class Storage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String DIR = ".revault";
    private static final String FILE = "saved_sites.json";

    private static Path baseDir() {
        Path dir = Paths.get(System.getProperty("user.home")).resolve(DIR);
        try { Files.createDirectories(dir); } catch (IOException ignored) { }
        return dir;
    }

    public static List<SavedSite> load() {
        Path f = baseDir().resolve(FILE);
        if (!Files.exists(f)) return new ArrayList<>();
        try {
            Type type = new TypeToken<List<SavedSite>>() {}.getType();
            List<SavedSite> list = GSON.fromJson(Files.readString(f), type);
            return list != null ? list : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static void save(List<SavedSite> sites) {
        if (sites == null) return;
        try {
            Files.writeString(baseDir().resolve(FILE), GSON.toJson(sites));
        } catch (IOException ignored) { }
    }

    public static class SavedSite {
        public int id;
        public String url;
        public String title;
        public long savedAt;

        public SavedSite() { }

        public SavedSite(int id, String url, String title) {
            this.id = id;
            this.url = url;
            this.title = title != null && !title.isBlank() ? title : url;
            this.savedAt = System.currentTimeMillis();
        }
    }
}
