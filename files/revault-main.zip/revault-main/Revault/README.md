# Revault

Private website saver with an oldschool terminal-style UI. Lightweight, local-only.

## Setup

```bash
./setup.sh
./run.sh
```

Requires Java 17+. Data is stored in `~/.revault/saved_sites.json`.

## Commands

| Command | Description |
|--------|-------------|
| `save <url> [title]` | Save a site (title optional) |
| `list` | List all saved sites |
| `open <id>` | Open in your browser |
| `delete <id>` | Remove a saved site |
| `edit <id> <url>` | Change the URL |
| `edit <id> -t "title"` | Change the title |
| `clear` | Clear the screen |
| `help` | Show commands |
| `quit` | Exit |

## Examples

```
> save https://example.com
> save https://wiki.archlinux.org Arch Wiki
> list
> open 1
> edit 2 -t "Arch Linux Wiki"
> delete 1
```
